# Transactional macOS app install and rollback

Use this reference when a script assembles, replaces, launches, or rolls back a locally installed `.app` bundle.

## Invariants

- The staged candidate is fully assembled, signed, and verified before the installed bundle is touched.
- Process termination matches the exact absolute executable path. A display name, bundle name, or broad process-name match is insufficient.
- The previous installed bundle becomes the backup only after it has been verified.
- Rollback validates the backup before any destructive action.
- Rollback does not validate the failed candidate. Candidate corruption may be the reason rollback is running.
- A failed or unusable backup preserves the current installed path for diagnosis rather than deleting it.

## Install ordering

1. Reconcile any prior backup without overwriting an unverified path.
2. Verify the currently installed bundle when present.
3. Build and fully verify a staged candidate.
4. Stop only the exact installed executable.
5. Rename the installed bundle to the backup path.
6. Rename the staged candidate to the installed path.
7. Launch and verify the installed candidate.
8. Remove the backup only after the new candidate is proven.

Keep the rename and launch operations inside the rollback-protected region. Record whether the old app was running so successful rollback can restore its lifecycle state.

## Rollback ordering

1. When replacement was intended, require the backup path and reject symlinks.
2. Fully verify the backup, including directory shape, metadata, executable, and signature. Allow only explicitly supported compatibility exceptions, such as notices introduced after the backup version.
3. Stop a candidate process by the exact installed executable path without verifying the candidate bundle.
4. Remove the failed candidate.
5. Rename the verified backup to the installed path.
6. Relaunch and verify it when the previous app was running.

The key asymmetry is deliberate: trust must be established for the artifact being restored, while the artifact being removed may be malformed.

## Regression probes

Run probes in an isolated temporary installation root. Use a copy of a real signed bundle when signature verification is part of the contract.

- Valid backup plus corrupt candidate: rollback restores the backup and consumes the backup path.
- Missing backup: rollback fails before removal and preserves the current bundle.
- Symlink backup: rollback fails before removal and preserves the current bundle.
- Regular-file backup: rollback fails before removal and preserves the current bundle.
- Corrupt-directory backup: rollback fails before removal and preserves the current bundle.
- Backup-creation rename failure: the original installed bundle remains untouched.
- Candidate launch or verification failure: the verified backup is restored.
- Running candidate: only the exact candidate executable is terminated.

After the isolated probes, exercise the repository's real build and verify commands against the installed Release artifact. Compilation or a mocked filesystem alone does not prove the transaction.
